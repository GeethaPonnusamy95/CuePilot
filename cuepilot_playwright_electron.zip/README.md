# CuePilot Playwright Test Suite

## Setup

```bash
npm install
npx playwright install
```

## Run Tests

```bash
npx playwright test
```
