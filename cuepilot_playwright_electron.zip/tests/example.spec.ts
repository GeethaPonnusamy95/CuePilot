import { test, expect } from '@playwright/test';

test('CuePilot opens overlay on hotkey', async ({ page }) => {
  // Simulate selected text and hotkey press
  await page.keyboard.press('Meta+Shift+R');
  // Expect overlay to be visible
  await expect(page.locator('#cuepilot-overlay')).toBeVisible();
});
